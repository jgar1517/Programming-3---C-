// Pointers Lab 1.cpp : This file contains the 'main' function. Program execution begins and ends there.
// Programming 3 - NVC
// Auhtor: Jonathan Garcia
// Program that demonstrates pointers 

#include <iostream>
#include <string>
using namespace std;

    int main() {
        // declare an integer variable myNumber and assign a value of 5
        int myNumber;
        myNumber = 5;
        // declare a pointer variable myPointer of type integer
        int* myPointer = nullptr;
        // assign the memory address of myNumber to the pointer variable myPointer
       myPointer = &myNumber;
        // print the value of myNumber
        cout << "The value of myNumber: " << myNumber << endl;
        // print the memory address of myNumber
        cout << "The memory address of myNumber: " << &myNumber << endl;
        // print the value of the pointer variable myPointer
        cout << "The value of the pointer variable myPointer: " << myPointer << endl;
        // print the value pointed to by myPointer (which is the value of myNumber)
        cout << "The value pointed to by myPointer: " << *myPointer << endl;

        return 0;
    }

