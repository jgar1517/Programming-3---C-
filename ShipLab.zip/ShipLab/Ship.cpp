// Programming 3 - NVC
// Author - Jonathan Garcia
// Inheritance Lab 1 - Ship 
// Program that is an example of inheritance
// Ship.cpp File 

#include "Ship.h"

	
	
	//Setters // Mutators
	//field for the name of the ship 
	void Ship::setName(std::string sName) {
		name = sName;
	}

	// field for the year the ship was made
	void Ship::setYear(int sYear) {
		year = sYear;
	}

	//Getters // Accessors
	std::string Ship::getName() const {
		return name;
	}
	int Ship::getYear() const {
		return year;
	}

	//Functions 
	//Print mehtod that displays the ships name and the year it was built 

	string Ship::print() {

		string myReturn = "";
		myReturn += "Ship Name: " + getName() + "\n";
		myReturn += "Year Built: " + to_string(getYear()) + "\n";
		return myReturn;
	}

	
	// Constructor with appropriate accessors and mutators 
	
	Ship::Ship(std::string name, int year) {
		this->name = name;
		this->year = year;
		
	}