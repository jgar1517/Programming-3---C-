// Ship Lab1.cpp : This file contains the 'main' function. Program execution begins and ends there.
// // Programming 3 - NVC
// Author - Jonathan Garcia
// Inheritance Lab 1 - Ship 
// Program that is an example of inheritance
// Main.cpp File 

#include <iostream>
#include "CruiseShip.h"
#include "CargoShip.h"
#include <vector>

int main()
{
	// Program header
	cout << ("---------------Ship Program---------------") << endl;

	// Vector called myShips to store pointers to the Ship Class. 
	vector<Ship*> myShips;

	// variables for each ship 
	string name;
	int year;
	int cargoCap;
	int maxPassengers;

	// Prompt User for each attribute of a cargo and cruise ship 
	cout << "Please enter the name of the Ship: ";
	cin >> name;
	cout << "Please enter the year the ship was built: ";
	cin >> year;
	cout << "Please enter the Maximum number of Passengers for the ship: ";
	cin >> maxPassengers;
	cout << "Please enter the Cargo Capacity of the Ship in Tons: ";
	cin >> cargoCap;
	cout << endl; 



	// Push_Back Functions with Parameters 
	myShips.push_back(new CruiseShip(name, year, maxPassengers));
	myShips.push_back(new CargoShip(name, year, cargoCap));


	//Display each objects informatino using the print method 
	for (Ship* myShipPointer : myShips)
	{
		cout << myShipPointer->print() << endl;
	}

	// Range- based for loop used to delete each object pointed to by the pointers in the myShips vector. This releases the memory each object was using and is essential in C++ where dynamic allocatino is used 
	for (Ship* myShip : myShips)
	{
		delete myShip;
	}


}