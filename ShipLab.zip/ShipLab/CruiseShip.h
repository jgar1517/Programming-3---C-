// Programming 3 - NVC
// Author - Jonathan Garcia
// Inheritance Lab 1 - Ship 
// Program that is an example of inheritance
// CruiseShip.h File 

#pragma once
#include "Ship.h"
#include <stdio.h> /// provides functions for input/ output operations

// Derivied class CruiseShip from Ship Class 

class CruiseShip : public Ship
{
    private:
        // Class Variable for max number of passengers
        int maxPassengers;
      
    public:
        // Setter for variable
        void setMaxPassengers(int);

        // Getter for variable
        int getMaxPassengers() const;

        // Constructor 
        CruiseShip(string name = "", int year = 0, int maxPassengers = 0);

        // Function that prints the information from the base class(Ship Class) 
        string print() override;
      
};

