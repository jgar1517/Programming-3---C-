// Programming 3 - NVC
// Author - Jonathan Garcia
// Inheritance Lab 1 - Ship 
// Program that is an example of inheritance
// Ship.h file 
#pragma once

#include <iostream>
#include <stdio.h>
#include <string>
using namespace std;

class Ship
{
private:

    //private class variables
    string name;
    int year;

public:
    //Setters 
    void setName(string);
    void setYear(int);
   
    //Getters 
    string getName() const;
    int getYear() const;
   
    //Constructors
    Ship(string name = "", int year = 0);

    virtual string print();
};

