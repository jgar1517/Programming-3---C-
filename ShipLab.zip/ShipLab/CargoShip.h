// Programming 3 - NVC
// Author - Jonathan Garcia
// Inheritance Lab 1 - Ship 
// Program that is an example of inheritance
// CargoShip.h File 

#pragma once
#include "Ship.h"
#include <stdio.h>

class CargoShip : public Ship 
{
protected:
    // CargoShip Class Variable 
    int cargoCap;

public:
    // CargoShip Class Setter
    void setcargoCap(int);


    // CargoShip Class Getter
    int getcargoCap() const;

    //Constructors
    CargoShip(string name = "", int year = 0, int cargoCap = 0);

    //Functions to print from the Ship, CruiseShip and CargoShip Class 
    
   string print() override;
};

