// Programming 3 - NVC
// Author - Jonathan Garcia
// Inheritance Lab 1 - Ship 
// Program that is an example of inheritance
// CruiseShip.cpp File 

#include "CruiseShip.h"
#include "CargoShip.h"

// Setter for CruiseShip Class
void CruiseShip::setMaxPassengers(int sNumPass) {
    maxPassengers = sNumPass;

}
// Getter for CruisShip Class
int CruiseShip::getMaxPassengers() const {
    return maxPassengers;
}
// Constructors 
CruiseShip::CruiseShip(std::string name, int year, int maxPassengers):Ship(name, year) {
    this->maxPassengers = maxPassengers;
}

// Functions 
std::string CruiseShip::print() {
    string myReturn = ("-----CruiseShip-----\n" ) + Ship::print();
    myReturn += "Max Passengers: " + to_string(getMaxPassengers()) + "\n";
    return myReturn;
}