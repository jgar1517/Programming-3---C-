// Programming 3 - NVC
// Author - Jonathan Garcia
// Inheritance Lab 1 - Ship 
// Program that is an example of inheritance
// CargoShip.cpp File 

#include "CargoShip.h"

// Setter for CargoShip Class
void CargoShip::setcargoCap(int sCargoCap) {
    cargoCap = sCargoCap;

}
// Getter for CargoShip Class
int CargoShip::getcargoCap() const {
    return cargoCap;
}
// Constructors 
CargoShip::CargoShip(std::string name, int year, int cargoCap):Ship(name, year) {
    this->cargoCap = cargoCap;
}

// Functions 
std::string CargoShip::print() {
    string myReturn = ("-----CargoShip-----\n") + Ship::print();
    myReturn += "Max Cargo in Tons: " + to_string(getcargoCap()) + "\n";
    return myReturn;
}