#include "ContactNode.h";

// Constructor with parameters for name followed by phone number
ContactNode::ContactNode(string name, string phoneNumber, ContactNode* nextLoc)
{
	this->contactName = name;
	this->contactPhoneNumber = phoneNumber;
	this->nextNodePtr = nextLoc;
}
// define "InsertAfter" - Insert new node after first node
void ContactNode::InsertAfter(ContactNode* nodeLoc)
{
	ContactNode* tmpNext = nullptr;

	tmpNext = this->nextNodePtr;  //Remember next
	this->nextNodePtr = nodeLoc;  //this -- node -- ?
	nodeLoc->nextNodePtr = tmpNext; //this -- node -- next
}

// define Print data memder function to print contactName and contactPhoneNumber 
void ContactNode::PrintNodeData() 
{
	cout << "Name: " << this->contactName << endl;
	cout << "Phone Number: " << this->contactPhoneNumber << endl;
	cout << endl;
}
// Define GetNext to get location pointed by nextNodePtr
	ContactNode* ContactNode::GetNext() {
	return this->nextNodePtr;
}
// Define GetName
void ContactNode::setName(string name) {
			this->contactName = name;
}
void ContactNode::setPhoneNumber(string phoneNumber) {
		 this->contactPhoneNumber = phoneNumber;
}

string ContactNode::GetName() {
	return contactName;
}
string ContactNode::GetPhoneNumber() {
	return contactPhoneNumber;
}