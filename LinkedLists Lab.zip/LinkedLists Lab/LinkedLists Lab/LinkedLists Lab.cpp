// LinkedLists Lab.cpp : This file contains the 'main' function. Program execution begins and ends there.
// Programming 3 - NVC
// Author: Jonathan Garcia
// Program that uses Linked lists to print a contact list 

#include "ContactNode.h"
#include <iostream>
#include <string> 
using namespace std;


int main()

{
	//Create three ContactNodes objects and use the nodes to build a linked list 
	ContactNode* headObj = nullptr;
	ContactNode* contact1 = nullptr;
	ContactNode* contact2 = nullptr;
	ContactNode* contact3 = nullptr;
	ContactNode* currObj = nullptr;

	//Front of nodes list
	headObj = new ContactNode();

	//Additional nodes are inserted after headObj using InsertAfter function 
	contact1 = new ContactNode();
	headObj->InsertAfter(contact1);

	contact2 = new ContactNode();
	contact1->InsertAfter(contact2);

	contact3 = new ContactNode();
	contact2->InsertAfter(contact3);

	string contactName;
	string contactPhoneNumber;


	//Definde main to read the name and phone number for three contacts and output each contact
	cout << "-----Contact Information-----" << endl;
	cout << "Enter First Contact Name: " << endl;
	cin >> contactName;
	contact1->setName(contactName);
	cout << "Enter Phone number for " << contactName << ": " << endl;
	cin >> contactPhoneNumber;
	contact1->setPhoneNumber(contactPhoneNumber);
	cout << "Person 1: " << contactName << ", " << contactPhoneNumber << endl;

	cout << "Enter Second Contact Name: " << endl;
	cin >> contactName;
	contact2->setName(contactName);
	cout << "Enter Phone number for " << contactName << ": " << endl;
	cin >> contactPhoneNumber;
	contact2->setPhoneNumber(contactPhoneNumber);
	cout << "Person 2: " << contactName << ", " << contactPhoneNumber << endl;

	cout << "Enter Third Contact Name: " << endl;
	cin >> contactName;
	contact3->setName(contactName);
	cout << "Enter Phone number for " << contactName << ": " << endl;
	cin >> contactPhoneNumber;
	contact3->setPhoneNumber(contactPhoneNumber);
	cout << "Person 3: " << contactName << ", " << contactPhoneNumber << endl;
	cout << endl;
	cout << "-----CONTACT LIST-----" << endl;


	//Print the linked list using a loop to output contacts one at a time(please include a newline between contacts)
	currObj = contact1;
	while (currObj != nullptr)
	{
		currObj->PrintNodeData();
		currObj = currObj->GetNext();
	}

	delete headObj;

	return 0;
}
