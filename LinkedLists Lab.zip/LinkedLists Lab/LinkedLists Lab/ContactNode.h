#pragma once


#include <iostream>
#include <string>
using namespace std;

class ContactNode
{
public:
	// Public member functions 
	//define get functions 
	ContactNode(string name = "", string phoneNumber = "", ContactNode* nextLoc = nullptr);
	void setName(string name);
	void setPhoneNumber(string phoneNumber);
	string GetName();
	string GetPhoneNumber();

	//insert node after this node
	void InsertAfter(ContactNode* nodeLoc);

	// Get location pointed by nextnodePtr
	ContactNode* GetNext();

	//Print data values 
	void PrintNodeData();

	// Data member values 
private:
	string contactName;
	string contactPhoneNumber;

	// Pointer to the next node 
	ContactNode* nextNodePtr;



};
